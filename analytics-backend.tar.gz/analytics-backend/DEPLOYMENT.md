# Deployment-Anleitung für VPS

## Voraussetzungen

- VPS mit SSH-Zugriff
- Node.js 20+ installiert
- Nginx als Reverse Proxy (für HTTPS)
- Domain: `metaprompt.celox.io`

## Schritt 1: Dateien auf VPS kopieren

```bash
# Auf lokalem Rechner
scp -r analytics-backend/* user@69.62.121.168:/var/www/html/api/metaprompt/
```

## Schritt 2: Auf VPS verbinden

```bash
ssh user@69.62.121.168
cd /var/www/html/api/metaprompt
```

## Schritt 3: Dependencies installieren

```bash
npm install --production
```

## Schritt 4: Umgebungsvariablen setzen

```bash
nano .env
```

Inhalt:
```
PORT=3000
ADMIN_KEY=<starker-zufälliger-key>
DB_PATH=/var/www/html/api/metaprompt/data/analytics.db
```

**Wichtig:** Generiere einen starken Admin-Key:
```bash
openssl rand -hex 32
```

## Schritt 5: Datenbank-Verzeichnis erstellen

```bash
mkdir -p data
chmod 755 data
```

## Schritt 6: Nginx-Konfiguration

Erstelle `/etc/nginx/sites-available/metaprompt-analytics`:

```nginx
server {
    listen 443 ssl http2;
    server_name metaprompt.celox.io;
    
    ssl_certificate /path/to/ssl/cert.pem;
    ssl_certificate_key /path/to/ssl/key.pem;
    
    # API Endpoints
    location /api/metaprompt {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
    
    # Admin Dashboard
    location /admin {
        alias /var/www/html/api/metaprompt/admin;
        index index.html;
        try_files $uri $uri/ =404;
    }
}
```

Aktiviere die Konfiguration:
```bash
sudo ln -s /etc/nginx/sites-available/metaprompt-analytics /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## Schritt 7: PM2 für Process Management

```bash
npm install -g pm2
pm2 start server.js --name metaprompt-analytics
pm2 save
pm2 startup
```

## Schritt 8: Firewall (falls aktiv)

```bash
sudo ufw allow 3000/tcp
```

## Schritt 9: Testen

```bash
# Health Check
curl http://localhost:3000/health

# Stats (mit Admin-Key)
curl "http://localhost:3000/api/stats?key=YOUR_ADMIN_KEY"
```

## Monitoring

```bash
# PM2 Status
pm2 status

# Logs
pm2 logs metaprompt-analytics

# Restart
pm2 restart metaprompt-analytics
```

## Backup

Die SQLite-Datenbank liegt unter:
```
/var/www/html/api/metaprompt/data/analytics.db
```

Backup-Script:
```bash
#!/bin/bash
BACKUP_DIR="/var/backups/metaprompt-analytics"
mkdir -p $BACKUP_DIR
cp /var/www/html/api/metaprompt/data/analytics.db $BACKUP_DIR/analytics-$(date +%Y%m%d).db
# Alte Backups löschen (älter als 30 Tage)
find $BACKUP_DIR -name "analytics-*.db" -mtime +30 -delete
```

Cron-Job (täglich um 2 Uhr):
```bash
0 2 * * * /path/to/backup-script.sh
```
